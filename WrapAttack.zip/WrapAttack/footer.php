   <footer class="footer" style="background-color: #E8E8E8;">
                <div class="footer-newsletter">
                    <div class="container-fluid">
                        <h4>Stay in the know!</h4>
                        <p>Subscribe for the latest styles and sales, plus get 25% off your first order.</p>
                        <form>
                            <input type="email" class="form-control" placeholder="your@email.com" required>
                            <button type="submit" class="btn btn-custom">Sign Up</button>
                        </form>
                    </div><!-- End .container-fluid -->
                </div><!-- End .footer-newsletter -->

                <div class="footer-top">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-3 col-sm-6">
                                <div class="widget">
                                    <h4 class="widget-title">Top Rated</h4>
                                    <ul class="products-list">
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product1.jpg" alt="Product">
                                                </a>
                                                <span class="product-label discount">-25%</span>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Navy blue silk pleated dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$250.00</span>
                                                    <span class="product-old-price">$350.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product2.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Mustard yellow ruffle dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$214.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product3.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Asymmetric crew neck sweater</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$1450.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-md-3 -->
                            <div class="col-md-3 col-sm-6">
                                <div class="widget">
                                    <h4 class="widget-title">On Sale</h4>
                                    <ul class="products-list">
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product4.png" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Navy blue silk pleated dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$1200.00</span>
                                                    <span class="product-old-price">$1500.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product5.jpg" alt="Product">
                                                </a>
                                                <span class="product-label">New</span>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Mustard yellow ruffle dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$858.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product6.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Asymmetric crew neck sweater</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$360.00</span>
                                                    <span class="product-old-price">$400.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-md-3 -->
                            <div class="col-md-3 col-sm-6">
                                <div class="widget">
                                    <h4 class="widget-title">Top Sellers</h4>
                                    <ul class="products-list">
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product7.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Navy blue silk pleated dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$750.00</span>
                                                    <span class="product-old-price">$1800.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product8.jpg" alt="Product">
                                                </a>
                                                <span class="product-label discount">-40%</span>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Mustard yellow ruffle dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$260.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product9.jpg" alt="Product">
                                                </a>
                                                <span class="product-label outofstock">Out Of<br>Stock</span>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Asymmetric crew neck sweater</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$345.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-md-3 -->
                            <div class="col-md-3 col-sm-6">
                                <div class="widget">
                                    <h4 class="widget-title">Recommended</h4>
                                    <ul class="products-list">
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product10.jpg" alt="Product">
                                                </a>
                                                <span class="product-label">New</span>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Navy blue silk pleated dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$250.00</span>
                                                    <span class="product-old-price">$1500.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product11.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Mustard yellow ruffle dress</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$1235.00</span>
                                                    <span class="product-old-price">$1400.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                        <li class="product">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/thumbs/product12.jpg" alt="Product">
                                                </a>
                                            </figure>
                                            <div class="product-meta">
                                                <h5 class="product-title">
                                                    <a href="#">Asymmetric crew neck sweater</a>
                                                </h5>
                                                <div class="product-price-container">
                                                    <span class="product-price">$650.00</span>
                                                </div><!-- End .product-price-container -->
                                            </div><!-- End .product-meta -->
                                        </li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-md-3 -->
                        </div><!-- End .row -->
                    </div><!-- End .container-fluid -->
                </div><!-- End .footer-top -->

                <div class="footer-inner">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-5 col-sm-4">
                                <div class="widget about-widget">
                                    <img src="assets/images/footer-logo.png" class="footer-logo" alt="Simple Footer Logo">
                                    <p>Nulla facilisi. Aliquam dictum in as tempor libero, ac iaculis arcu accumsan at  eros vel nibh.</p>
                                    <p>Integer ultricies a mattis.  Etiam venenatis lorem in purus susci pit, id blandit dignissim. Sem at purus ultrices vehicula.</p>
                                </div><!-- End .widget -->
                            </div><!-- End .col-5 -->

                            <div class="col-5 col-sm-4">
                                <div class="widget">
                                    <h4 class="widget-title">Information</h4>
                                    <ul class="links">
                                        <li><a href="#">New products</a></li>
                                        <li><a href="#">Top sellers</a></li>
                                        <li><a href="#">Specials products</a></li>
                                        <li><a href="#">Manufacturers</a></li>
                                        <li><a href="#">Suppliers</a></li>
                                        <li><a href="#">Our Stores</a></li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-5 -->

                            <div class="col-5 col-sm-4">
                                <div class="widget">
                                    <h4 class="widget-title">Customer Service</h4>
                                    <ul class="links">
                                        <li><a href="#">Help &amp; Contact</a></li>
                                        <li><a href="#">Shipping &amp; Taxes</a></li>
                                        <li><a href="#">Return Policy</a></li>
                                        <li><a href="#">Careers</a></li>
                                        <li><a href="#">Affiliates</a></li>
                                        <li><a href="#">Legal Notice</a></li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-5 -->

                            <div class="col-5 col-sm-4">
                                <div class="widget">
                                    <h4 class="widget-title">My Account</h4>
                                    <ul class="links">
                                        <li><a href="#">My Account</a></li>
                                        <li><a href="#">Personal Information</a></li>
                                        <li><a href="#">Addresses</a></li>
                                        <li><a href="#">Discount</a></li>
                                        <li><a href="#">Order History</a></li>
                                        <li><a href="#">Your Vouchers</a></li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-5 -->

                            <div class="col-5 col-sm-4">
                                <div class="widget">
                                    <h4 class="widget-title">Contact Details</h4>
                                    <ul class="contact-list">
                                        <li>
                                            <i class="icon info-icon phone"></i>
                                            <div>0203 - 980 - 14 - 79</div>
                                            <div>0203 - 980 - 14 - 79</div>
                                        </li>
                                        <li>
                                            <i class="icon info-icon mobile"></i>
                                            <div>445 - 115 - 747 - 38</div>
                                            <div>455 - 170 - 029 - 32</div>
                                        </li>
                                        <li>
                                            <i class="icon info-icon email"></i>
                                            <div><a href="mailto:#">sconto_shop@hotmail.com</a></div>
                                            <div><a href="mailto:#">sconto@hotmail.com</a></div>
                                        </li>
                                        <li>
                                            <i class="icon info-icon skype"></i>
                                            <div>sconto_shop_contact</div>
                                            <div>sconto_support</div>
                                        </li>
                                    </ul>
                                </div><!-- End .widget -->
                            </div><!-- End .col-5 -->
                        </div><!-- End .row -->
                    </div><!-- End .container-fluid -->
                </div><!-- End .footer-inner -->

                <div class="footer-bottom">
                    <div class="container-fluid">
                        <div class="footer-left">
                            <div class="social-icons">
                                <a href="#" class="social-icon icon facebook" title="Facebook"><span class="sr-only">Facebook</span></a>
                                <a href="#" class="social-icon icon twitter" title="Twitter"><span class="sr-only">Twitter</span></a>
                                <a href="#" class="social-icon icon pinterest" title="Pinterest"><span class="sr-only">Pinterest</span></a>
                                <a href="#" class="social-icon icon instagram" title="Instagram"><span class="sr-only">Instagram</span></a>
                                <a href="#" class="social-icon icon flickr" title="Flickr"><span class="sr-only">Flickr</span></a>
                                <a href="#" class="social-icon icon skype" title="Skype"><span class="sr-only">Skype</span></a>
                                <a href="mailto:#" class="social-icon icon email" title="Email"><span class="sr-only">Email</span></a>
                            </div><!-- End .social-icons -->
                            <ul class="footer-menu">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Information</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#">Free Delivery</a></li>
                                <li><a href="#">Support</a></li>
                            </ul>
                        </div><!-- End .footer-right -->

                        <div class="footer-right">
                            <div class="payment-info">
                                <h5>100% Secure and Trusted Payment</h5>
                                <p>Easy returns. Free shipping on orders over $100. Need help? <a href="#">Help Center.</a></p>
                                <img src="assets/images/cards.png" alt="Payment methods">
                            </div><!-- End .payment-info -->
                        </div><!-- End .footer-right -->

                        <a class="scroll-top icon" href="#top" title="Scroll top"><span class="sr-only">Scroll Top</span></a>
                    </div><!-- End .container-fluid -->
                </div><!-- End .footer-bottom -->
            </footer><!-- End .footer -->