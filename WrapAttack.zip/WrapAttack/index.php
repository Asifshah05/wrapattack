<!DOCTYPE html>
<!--[if IE 9]><html class="ie9"><![endif]-->
<!--[if !IE]><!--><html><!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <title>Wrap Attack</title>
        <meta name="description" content="Premium eCommerce Template">

        <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicons/favicon.png">
        <link rel="apple-touch-icon" sizes="57x57" href="assets/images/favicons/faviconx57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="assets/images/favicons/faviconx72.png">

        <link href='http://fonts.googleapis.com/css?family=Hind:400,700,600,500,300%7CFira+Sans:400,700italic,500italic,400italic,300italic,700,500,300' rel='stylesheet' type='text/css'>

        <!-- Fira Sans Fix - Google Fira Sans sometimes fails to load -->
        <link href='http://code.cdn.mozilla.net/fonts/fira.css' rel='stylesheet'>

        <link rel="stylesheet" href="assets/css/plugins.min.css">
        <link rel="stylesheet" href="assets/css/settings.css">
        <link rel="stylesheet" href="assets/css/navigation.css">
        <link rel="stylesheet" href="assets/css/style.css">

    </head>
    <body>
       <?php include 'header.php';?>
            <div class="main">

                <div id="rev_slider_wrapper" class="rev_slider_bgcheck rev_slider_wrapper rev_container_1 fullwidthbanner-container" data-alias="classicslider1">
                    <div id="rev_slider" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">
                        <ul>
                            <!-- SLIDE  -->
                            <li data-index="rs-1" data-transition="slideoverup" data-slotamount="7"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="1200"  data-thumb="assets/images/homesliders/index2/slide1.jpg"  data-rotate="0"  data-saveperformance="on"  data-title="Corporate">

                                <!-- MAIN IMAGE -->
                                <img src="assets/images/homesliders/index2/slide1.jpg"  alt="Slider bg 1"  data-bgposition="center center" data-duration="11000" data-ease="Linear.easeNone" class="rev-slidebg" data-no-retina>
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption revslider-title text-white text-uppercase text-center tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-1-layer-1" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['0','0','0','0', '20']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['-60','-60','-50','-40','-10']" 
                                    data-fontsize="['80','80','64','50','32']"
                                    data-lineheight="['80','80','64','50','32']"
                                    data-fontweight="700"
                                    data-width="none"
                                    data-height="none"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="x:[-105%];z:0;rX:0deg;rY:0deg;rZ:-90deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;"
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="800" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    data-elementdelay="0.1" 
                                    style="z-index: 5; white-space: nowrap;">love that <br> you’re using
                                </div>

                                <!-- LAYER NR. 2 -->
                                <div class="tp-caption revslider-subtitle text-uppercase tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-1-layer-2" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['190','190','140','104','76']" 
                                    data-y="['middle','middle','middle','middle']" data-voffset="['-176','-176','-140','-112','-60']" 
                                    data-width="none"
                                    data-height="none"
                                    data-fontsize="['18','18','16','13','10']"
                                    data-lineheight="['18','18','16','13','10']"
                                    data-fontweight="600"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="1300" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    style="z-index: 6; white-space: nowrap;">mobile Skin &amp; gadget skin
                                </div>

                                <!-- LAYER NR. 3 -->
                                <div class="tp-caption revslider-text text-center tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-1-layer-3" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['55','55','30','0','0']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['60','60','45','40','25']" 
                                    data-width="['500px','500px','420px','380px','280px']"
                                    data-height="none"
                                    data-fontsize="['17','17','15','13','10']"
                                    data-lineheight="['23','23','20','18','16']"
                                    data-whitespace="normal"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="1300" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    style="z-index: 6;">Fusce bibendum dui at ornare aliquet. Nulla ultrices tempor ullamcorper. Maecenas ornare nunc non rutrum.
                                </div>

                                <!-- LAYER NR. 4 -->
                                <a class="tp-caption btn btn-white tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-1-layer-4" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['230','230','180','134','96']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['138','138','110','100','50']" 
                                    data-width="['156px','156px', '138px', '120px', 80px']"
                                    data-fontsize="['15','14','13','12','9']"
                                    data-paddingtop="['13','13','11','9','5']"
                                    data-paddingbottom="['10','10','7','6','2']"
                                    data-height="none"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="2000" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    style="z-index: 6; white-space: nowrap;"
                                    href="#">Shop Now
                                </a>
                            </li>
                            <!-- SLIDE  -->
                            <li data-index="rs-2" data-transition="slideoverdown" data-slotamount="7" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="1200" data-thumb="assets/images/homesliders/index2/slide2.jpg" data-rotate="0" data-saveperformance="on" data-title="Business">

                                <!-- MAIN IMAGE -->
                                <img src="assets/images/homesliders/index2/slide2.jpg"  alt="Slider bg 2"  data-bgposition="center center" data-duration="11000" data-ease="Linear.easeNone" class="rev-slidebg" data-no-retina>
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption revslider-title darker text-uppercase text-center tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-2-layer-1" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['0','0','0','0', '20']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['-60','-60','-50','-40','-10']" 
                                    data-fontsize="['80','80','64','50','32']"
                                    data-lineheight="['80','80','64','50','32']"
                                    data-fontweight="700"
                                    data-width="none"
                                    data-height="none"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="x:[105%];z:0;rX:45deg;rY:0deg;rZ:90deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;"
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="800" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    data-elementdelay="0.05" 
                                    style="z-index: 5; white-space: nowrap;">Skin is <br>the new <span class="text-custom">Fashion</span>
                                </div>

                                <!-- LAYER NR. 2 -->
                                <div class="tp-caption  revslider-subtitle text-uppercase tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-2-layer-2" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['220','220','167','128','95']" 
                                    data-y="['middle','middle','middle','middle']" data-voffset="['-176','-176','-140','-112','-60']" 
                                    data-width="none"
                                    data-height="none"
                                    data-fontsize="['18','18','16','13','10']"
                                    data-lineheight="['18','18','16','13','10']"
                                    data-fontweight="600"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="1300" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on"
                                    style="z-index: 6; white-space: nowrap;">Fit for every mobile
                                </div>

                                <!-- LAYER NR. 3 -->
                                <div class="tp-caption revslider-text text-center tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-2-layer-3" 
                                   data-x="['right','right','right','right','right']" data-hoffset="['55','55','30','0','0']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['60','60','45','40','25']" 
                                    data-width="['500px','500px','420px','380px','280px']"
                                    data-height="none"
                                    data-fontsize="['17','17','15','13','10']"
                                    data-lineheight="['23','23','20','18','16']"
                                    data-whitespace="normal"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="1300" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    style="z-index: 6;">Design, features and specifications subject to change without notice. Screen images simulated &amp; dramatized.
                                </div>

                                <!-- LAYER NR. 4 -->
                                <a class="tp-caption btn btn-custom tp-resizeme rs-parallaxlevel-0" 
                                    id="slide-2-layer-4" 
                                    data-x="['right','right','right','right','right']" data-hoffset="['230','230','180','134','96']" 
                                    data-y="['middle','middle','middle','middle','middle']" data-voffset="['138','138','110','100','50']" 
                                    data-width="['156px','156px', '138px', '120px', 80px']"
                                    data-fontsize="['15','14','13','12','9']"
                                    data-paddingtop="['13','13','11','9','5']"
                                    data-paddingbottom="['10','10','7','6','2']"
                                    data-height="none"
                                    data-whitespace="nowrap"
                                    data-transform_idle="o:1;"
                                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                    data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                    data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
                                    data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                    data-start="2000" 
                                    data-splitin="none" 
                                    data-splitout="none" 
                                    data-responsive_offset="on" 
                                    style="z-index: 6; white-space: nowrap;"
                                    href="#">Shop Now
                                </a>

                            </li>
                        </ul>
                        <div class="tp-bannertimer" style="height: 4px; background-color: rgba(255, 255, 255, 0.5);"></div>  
                    </div><!-- End rev_slider -->
                </div><!-- End rev_slider_wrapper -->

                <div class="mb80 mb60-sm mb50-xs"></div><!-- margin -->

                <div class="container-fluid">
                    <div class="products-tab-container" role="tabpanel">
                        <!-- Nav tabs -->
                        <ul class="nav nav-pills nav-bordered text-center text-uppercase" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#tab-special" aria-controls="tab-special" role="tab" data-toggle="tab">
                                    Special
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#tab-latest" aria-controls="tab-latest" role="tab" data-toggle="tab">
                                    Latest
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#tab-bestsellers" aria-controls="tab-bestsellers" role="tab" data-toggle="tab">
                                    Bestsellers
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#tab-features" aria-controls="tab-features" role="tab" data-toggle="tab">
                                    Features
                                </a>
                            </li>
                        </ul>

                        <!-- Tab Panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="tab-special">
                                <div class="row product-container-row">
                                    <div class="products-container max-col-5" data-layoutmode="fitRows">
                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">-25%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product1.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">40-inch Class 1080p Smart Slim <br> LED HDTV with Wi-fi</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$1800.00</span>
                                                    <span class="product-price">$1210.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product2.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Toshiba</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Bass Effect Audio  Portable Wireless<br>Bluetooth Speaker</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$1050.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #c5c6c8;"></span>
                                                    <span style="background-color: #454545;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product3.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Acer</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 100%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Encore 32 GB Net-tablet PC<br>Clear SuperView</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$750.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #dfe0e2;"></span>
                                                    <span style="background-color: #b5b5b5;"></span>
                                                    <span style="background-color: #f39cb9;"></span>
                                                    <span style="background-color: #d5b56e;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label outofstock">Out Of<br>Stock</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product4.png" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Huawei</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">MediaPad White Unlocked<br>GSM Tablet</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$820.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product5.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Lenovo</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">ThinkPad T420 Intel Core i5<br>Laptop Computer </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$850.00</span>
                                                    <span class="product-price">$800.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #c5c6c8;"></span>
                                                    <span style="background-color: #454545;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">-100%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product6.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">HP Pavilion</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Touchscreen LED (BrightView)<br>Notebook </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$787.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #c5c6c8;"></span>
                                                    <span style="background-color: #454545;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product7.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Toshiba</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Windows 8, Intel Quad Core<br>tablet, IPS Screen</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$870.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #c5c6c8;"></span>
                                                    <span style="background-color: #454545;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product8.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Enziven</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Red Digital Camera with Bonus<br>Accessory Kit</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$290.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #aac4cc;"></span>
                                                    <span style="background-color: #c2a364;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product9.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">HP Pavilion</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet<br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$450.00</span>
                                                    <span class="product-price">$600.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product10.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black<br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c8c8c8;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->
                                    </div><!-- End .product-container-->
                                </div><!-- End .row -->
                            </div><!-- End .tab-pane -->

                            <div role="tabpanel" class="tab-pane" id="tab-latest">
                                <div class="row product-container-row">
                                    <div class="products-container max-col-5" data-layoutmode="fitRows">
                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">10%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product11.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Avanti</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Trio Stealth Pro Tablet Wireless Cortex<br>Actions Cortex</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$787.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #827172;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product12.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Panasonic</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Windows 8, Intel Quad Core<br>tablet, IPS Screen</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$787.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #f0f0f0;"></span>
                                                    <span style="background-color: #ade7f2;"></span>
                                                    <span style="background-color: #7af9a1;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product13.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Silver Digital Camera with 2 Batteries and<br>Card Bundle</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$1800.00</span>
                                                    <span class="product-price">$1210.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #877060;"></span>
                                                    <span style="background-color: #5b5a5a;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product14.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Bass Effect Audio  Portable Wireless <br>Bluetooth Speaker</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$1050.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product15.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Whynter</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 100%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber-shot DSC Megapixel Compact <br>Camera - Black</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$750.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #ddd5d2;"></span>
                                                    <span style="background-color: #b1afb0;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">-10%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product16.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Olympus</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Panasonic Lumix Red Digital Camera<br>and Card Bundle</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$800.00</span>
                                                    <span class="product-price">$650.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #ce9764;"></span>

                                                    <span style="background-color: #bab9b7;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product17.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Mediapad</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet <br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$600.00</span>
                                                    <span class="product-price">$450.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product18.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black <br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c9c9c9;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product9.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">HP Pavilion</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet<br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$450.00</span>
                                                    <span class="product-price">$600.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product10.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black<br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c8c8c8;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->
                                    </div><!-- End .product-container-->
                                </div><!-- End .row -->
                            </div><!-- End .tab-pane -->

                            <div role="tabpanel" class="tab-pane" id="tab-bestsellers">
                                <div class="row product-container-row">
                                    <div class="products-container max-col-5" data-layoutmode="fitRows">
                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product8.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Enziven</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Red Digital Camera with Bonus<br>Accessory Kit</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$290.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #aac4cc;"></span>
                                                    <span style="background-color: #c2a364;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product9.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">HP Pavilion</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet<br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$450.00</span>
                                                    <span class="product-price">$600.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product10.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black<br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c8c8c8;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">10%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product11.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Avanti</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Trio Stealth Pro Tablet Wireless Cortex<br>Actions Cortex</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$787.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #827172;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product12.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Panasonic</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Windows 8, Intel Quad Core<br>tablet, IPS Screen</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$787.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #f0f0f0;"></span>
                                                    <span style="background-color: #ade7f2;"></span>
                                                    <span style="background-color: #7af9a1;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product13.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Silver Digital Camera with 2 Batteries and<br>Card Bundle</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$1800.00</span>
                                                    <span class="product-price">$1210.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #877060;"></span>
                                                    <span style="background-color: #5b5a5a;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product14.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Bass Effect Audio  Portable Wireless <br>Bluetooth Speaker</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$1050.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product15.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Whynter</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 100%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber-shot DSC Megapixel Compact <br>Camera - Black</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$750.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #ddd5d2;"></span>
                                                    <span style="background-color: #b1afb0;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">-10%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product16.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Olympus</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Panasonic Lumix Red Digital Camera<br>and Card Bundle</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$800.00</span>
                                                    <span class="product-price">$650.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #ce9764;"></span>

                                                    <span style="background-color: #bab9b7;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product17.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Mediapad</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet <br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$600.00</span>
                                                    <span class="product-price">$450.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->
                                    </div><!-- End .product-container-->
                                </div><!-- End .row -->
                            </div><!-- End .tab-pane -->

                            <div role="tabpanel" class="tab-pane" id="tab-features">
                                <div class="row product-container-row">
                                    <div class="products-container max-col-5" data-layoutmode="fitRows">
                                       <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product14.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Samsung</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Bass Effect Audio  Portable Wireless <br>Bluetooth Speaker</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$1050.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product4.png" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Acer</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 100%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Encore 32 GB Net-tablet PC<br>Clear SuperView</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$900.00</span>
                                                    <span class="product-price">$750.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #dfe0e2;"></span>
                                                    <span style="background-color: #b5b5b5;"></span>
                                                    <span style="background-color: #f39cb9;"></span>
                                                    <span style="background-color: #d5b56e;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label outofstock">Out Of<br>Stock</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product4.png" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Huawei</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">MediaPad White Unlocked<br>GSM Tablet</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$820.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product5.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Lenovo</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">ThinkPad T420 Intel Core i5<br>Laptop Computer </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$850.00</span>
                                                    <span class="product-price">$800.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #c5c6c8;"></span>
                                                    <span style="background-color: #454545;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->


                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label discount">-10%</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product16.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Olympus</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Panasonic Lumix Red Digital Camera<br>and Card Bundle</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$800.00</span>
                                                    <span class="product-price">$650.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #ce9764;"></span>

                                                    <span style="background-color: #bab9b7;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product17.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Mediapad</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet <br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$600.00</span>
                                                    <span class="product-price">$450.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product18.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black <br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c9c9c9;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <span class="product-label">New</span>
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product8.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Enziven</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Red Digital Camera with Bonus<br>Accessory Kit</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-price">$290.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #aac4cc;"></span>
                                                    <span style="background-color: #c2a364;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product9.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                                    <div class="product-countdown"></div><!-- End .product-countdown -->
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">HP Pavilion</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Galaxy Note Pro 4G LTE Tablet<br>Titan Gray 7-Inch 16GB </a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$450.00</span>
                                                    <span class="product-price">$600.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #fff;"></span>
                                                    <span style="background-color: #b0dad6;"></span>
                                                    <span style="background-color: #bec2c5;"></span>
                                                    <span style="background-color: #4f4c44;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->

                                        <div class="product-column">
                                            <div class="product product1">
                                                <div class="product-top">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="assets/images/products/product10.jpg" alt="Product Image">
                                                        </a>
                                                    </figure>
                                                    <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                                </div><!-- End .product-top -->
                                                <div class="product-meta">
                                                    <div class="product-brand">
                                                        <a href="#">Planar</a>
                                                    </div><!-- End .product-brand -->
                                                    <div class="ratings-container">
                                                        <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                                    </div><!-- End .ratings -->
                                                </div><!-- End .product-meta -->

                                                <h3 class="product-title">
                                                    <a href="#">Cyber Shot Waterproof Black<br>Digital Camera</a>
                                                </h3>

                                                <div class="product-price-container">
                                                    <span class="product-old-price">$300.00</span>
                                                    <span class="product-price">$240.00</span>
                                                </div><!-- End .product-price-container -->

                                                <div class="product-colors">
                                                    <span style="background-color: #c8c8c8;"></span>
                                                    <span style="background-color: #b59b82;"></span>
                                                </div><!-- End .product-colors -->

                                                <div class="product-action">
                                                    <a href="#" class="btn-add-cart" title="Add to Cart"><i class="icon icon-cart"></i> <span>Add To Cart</span></a>
                                                    <a href="#" class="icon btn-product-like" title="Like"><span class="sr-only">Like</span></a>
                                                    <a href="#" class="icon btn-product-compare" title="Compare"><span class="sr-only">Compare</span></a>
                                                </div><!-- End .product-action -->
                                            </div><!-- End .product -->
                                        </div><!-- End .product-col -->
                                    </div><!-- End .product-container-->
                                </div><!-- End .row -->
                            </div><!-- End .tab-pane -->
                        </div><!-- End .tab-content -->
                    </div><!-- End role="tabpanel" -->
                </div><!-- End .container-fluid -->

                <div class="mb50 mb10-sm"></div><!-- margin -->

                <div class="container-fluid fullwidth">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="banner v2 text-right">
                                <a href="#">
                                    <img src="assets/images/banners/index2/banner1.jpg" alt="Banner">
                                </a>

                                <div class="banner-content light">
                                    <h4 class="wow fadeInRight">Weekly deals</h4>
                                    <h3 class="wow fadeInRight" data-wow-delay="0.1s">Explore great<br>saving</h3>
                                    <p class="wow fadeInRight" data-wow-delay="0.3s">Available this week on electronics <br> accessories.</p>
                                   <!--  <a href="#" class="btn btn-sm btn-white btn-border wow fadeInRight" data-wow-delay="0.5s">Watch Now</a> -->
                                </div><!-- End .banner-content -->
                            </div><!-- End .banner -->
                        </div><!-- End .col-sm-6 -->

                        <div class="col-sm-6">
                            <div class="banner v2">
                                <a href="#">
                                    <img src="assets/images/banners/index2/banner2.jpg" alt="Banner">
                                </a>

                                <div class="banner-content light">
                                    <h4 class="wow fadeInLeft">Discover Deals</h4>
                                    <h3 class="wow fadeInLeft" data-wow-delay="0.1s">on Tech<br>Accessories</h3>
                                    <p class="wow fadeInLeft" data-wow-delay="0.3s">When you need an accessory finding it  <br> online at Sconto Store. </p>
                                    <!-- <a href="#" class="btn btn-sm btn-white btn-border wow fadeInLeft" data-wow-delay="0.5s">Learn more</a> -->
                                </div><!-- End .banner-content -->
                            </div><!-- End .banner -->
                        </div><!-- End .col-sm-6 -->
                    </div><!-- End .row -->

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="banner v2 text-right">
                                <a href="#">
                                    <img src="assets/images/banners/index2/banner3.jpg" alt="Banner">
                                </a>

                                <div class="banner-content light">
                                    <h4 class="wow fadeInRight">Revolution in Washing</h4>
                                    <h3 class="wow fadeInRight" data-wow-delay="0.1s">Explore great<br>saving</h3>
                                    <p class="wow fadeInRight" data-wow-delay="0.3s">Bring a great look into your home <br> with elegant design.</p>
                                   <!--  <a href="#" class="btn btn-sm btn-white btn-border wow fadeInRight" data-wow-delay="0.5s">Take a look</a> -->
                                </div><!-- End .banner-content -->
                            </div><!-- End .banner -->
                        </div><!-- End .col-sm-6 -->

                        <div class="col-sm-6">
                            <div class="banner v2">
                                <a href="#">
                                    <img src="assets/images/banners/index2/banner4.jpg" alt="Banner">
                                </a>

                                <div class="banner-content">
                                    <h4 class="wow fadeInLeft">HEADPHONES</h4>
                                    <h3 class="wow fadeInLeft" data-wow-delay="0.1s">on Tech<br>Accessories</h3>
                                    <p class="wow fadeInLeft" data-wow-delay="0.3s">A selection of our favourite headphones  <br> available for you.</p>
                                    <!-- <a href="#" class="btn btn-sm btn-dark btn-border wow fadeInLeft" data-wow-delay="0.5s">Shop Now</a> -->
                                </div><!-- End .banner-content -->
                            </div><!-- End .banner -->
                        </div><!-- End .col-sm-6 -->
                    </div><!-- End .row -->
                </div><!-- End .container-fluid -->

                <div class="mb140 mb90-sm mb70-xs"></div><!-- margin -->

                <div class="container-fluid">
                    <div class="deal-carousel-container">
                        <h2 class="carousel-title text-center">DEAL OF THE DAY</h2>
                        <div class="swiper-container dealoftheday-carousel">
                            <!-- Add Navigation -->
                            <div class="swiper-nav-wrapper">
                                <div class="swiper-button-prev icon"></div><!-- End .button-prev -->
                                <div class="swiper-button-next icon"></div><!-- End .button-next -->
                            </div><!-- End .swiper-nav-wrapper -->

                            <div class="swiper-wrapper">

                                <div class="swiper-slide double">
                                     <div class="product wide">
                                        <span class="product-label discount">-25%</span>
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product-big1.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">SunpenTown</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Sound Blaster Tactic3D Rage Gaming Headset</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$800.00</span>
                                            <span class="product-price">$650.00</span>
                                        </div><!-- End .product-price-container -->

                                        <div class="product-countdown countdown-sep"></div><!-- End .product-countdown -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                                <div class="swiper-slide">
                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product13.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Samsung</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Silver Digital Camera with 2 Batteries and Card Bundle</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$1800.00</span>
                                            <span class="product-price">$1210.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->

                                    <div class="product">
                                        <span class="product-label discount">-30%</span>
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product16.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Olympus</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Panasonic Lumix Red Digital Camera and Card Bundle</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$800.00</span>
                                            <span class="product-price">$650.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                                <div class="swiper-slide">
                                    <div class="product">
                                        <span class="product-label discount">-25%</span>
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product14.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>

                                            <div class="product-countdown"></div><!-- End .product-countdown -->
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Toshiba</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Bass Effect Audio  Portable Wireless Bluetooth Speaker</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-price">$1050.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->

                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product11.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Avanti</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Trio Stealth Pro Tablet Wireless Cortex</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$900.00</span>
                                            <span class="product-price">$787.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                                <div class="swiper-slide">
                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product12.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Whynter</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Cyber-shot DSC Megapixel Compact Camera - Black</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-price">$750.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->

                                    <div class="product">
                                        <span class="product-label">New</span>
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product15.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Panasonic</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Windows 8, Intel Quad Core tablet, IPS Screen</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$900.00</span>
                                            <span class="product-price">$870.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                                <div class="swiper-slide">
                                    <div class="product">
                                        <span class="product-label">New</span>
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product4.png" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Toshiba</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Bass Effect Audio  Portable Wireless Bluetooth Speaker</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-price">$1050.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->

                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product8.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Avanti</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 80%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Trio Stealth Pro Tablet Wireless Cortex Actions Cortex</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-price">$480.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                                <div class="swiper-slide">
                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product2.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Whynter</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 60%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Cyber-shot DSC Megapixel Compact Camera - Black</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-price">$750.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->

                                    <div class="product">
                                        <div class="product-top">
                                            <figure>
                                                <a href="#">
                                                    <img src="assets/images/products/product10.jpg" alt="Product Image">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-quickview icon" title="View"><span class="sr-only">View</span></a>
                                        </div><!-- End .product-top -->
                                        <div class="product-meta">
                                            <div class="product-brand">
                                                <a href="#">Panasonic</a>
                                            </div><!-- End .product-brand -->
                                            <div class="ratings-container">
                                                <div class="ratings" style="width: 0%;"></div><!-- End .ratings -->
                                            </div><!-- End .ratings -->
                                        </div><!-- End .product-meta -->

                                        <h3 class="product-title">
                                            <a href="#">Windows 8, Intel Quad Core tablet, IPS Screen</a>
                                        </h3>

                                        <div class="product-price-container">
                                            <span class="product-old-price">$900.00</span>
                                            <span class="product-price">$870.00</span>
                                        </div><!-- End .product-price-container -->
                                    </div><!-- End .product -->
                                </div><!-- End .swiper-slide -->

                            </div><!-- End .swiper-wrapper -->
                        </div><!-- End .swiper-container -->
                    </div><!-- End .deal-carousel-container -->
                </div><!-- End .container-fluid -->

                <div class="mb120 mb70-sm mb35-xs"></div><!-- margin -->

                <div class="bg-custom7 pt60 pb70">
                    <div class="container-fluid">
                        <h2 class="carousel-title text-white text-center">WHAT PEOPLE ARE SAYING</h2>
                        <div class="swiper-container testimonials-3col-carousel">
                            <!-- Add Navigation -->
                            <div class="swiper-nav-wrapper">
                                <div class="swiper-button-prev icon light"></div><!-- End .button-prev -->
                                <div class="swiper-button-next icon light"></div><!-- End .button-next -->
                            </div><!-- End .swiper-nav-wrapper -->

                            <div class="swiper-wrapper">
                                <div class="swiper-slide testimonial">
                                    <blockquote>
                                        <p> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posu ere cubilia Curae; Quisque scelerisque mollis nisl vel volutpat. Aenean vitae eros magna. Aenean eleifend ligula at lacus.</p>
                                    </blockquote>
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="assets/images/blog/users/mark.png" alt="Mark">
                                        </figure>
                                        <div class="owner-meta">
                                            Mark Lewis,<br>
                                            06.04.2016
                                        </div>
                                    </div><!-- End .testimonial-owner -->
                                </div><!-- End .testimonial -->

                                <div class="swiper-slide testimonial">
                                    <blockquote>
                                        <p>Phasellus pulvinar, odio vestibulum porta suscipit, dolor tortor gravida nunc, nec blandit enim turpis vel odio. Mauris laoreet lectus eget mattis sodales. Praesent vel rhon cus sapien donec tempus.</p>
                                    </blockquote>
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="assets/images/blog/users/anna.png" alt="Grace">
                                        </figure>
                                        <div class="owner-meta">
                                            Anna Kendrick,<br>
                                            12.04.2016
                                        </div>
                                    </div><!-- End .testimonial-owner -->
                                </div><!-- End .testimonial -->

                                <div class="swiper-slide testimonial">
                                    <blockquote>
                                        <p>Aenean mattis at nulla a varius. Integer luctus eu nisi sit amet facilisis. Sed elemen porttitor, at egestas orci. Ut sit amet metus nisl. Nullam ligula turpis, blandit nec tellus et, pretium.</p>
                                    </blockquote>
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="assets/images/blog/users/grace.png" alt="Mark">
                                        </figure>
                                        <div class="owner-meta">
                                            Grace Lobot,<br>
                                            02.04.2016
                                        </div>
                                    </div><!-- End .testimonial-owner -->
                                </div><!-- End .testimonial -->

                                <div class="swiper-slide testimonial">
                                    <blockquote>
                                        <p>Sasellus pulvinar, odio vestibulum porta suscipit, dolor tortor gravida nunc, nec blandit enim turpis vel odio. Mauris laoreet lectus eget mattis sodales. Praesent vel rhon cus sapien donec tempusu.</p>
                                    </blockquote>
                                    <div class="testimonial-owner">
                                        <figure>
                                            <img src="assets/images/blog/users/david.png" alt="Mark">
                                        </figure>
                                        <div class="owner-meta">
                                            David Lobot,<br>
                                            02.04.2016
                                        </div>
                                    </div><!-- End .testimonial-owner -->
                                </div><!-- End .testimonial -->
                            </div><!-- End .swiper-wrapper -->
                        </div><!-- End .swiper-container -->
                    </div><!-- End .container-fluid -->
                </div><!-- bg-custom7 -->

                <div class="mb120 mb90-sm mb70-xs"></div><!-- margin -->

             
                <div class="mb20"></div><!-- margin -->

                <div class="container-fluid">
                    <h2 class="carousel-title text-center">INSTAGRAM FEED</h2>
                    <div class="swiper-container instagram-carousel">
                        <!-- Add Navigation -->
                        <div class="swiper-nav-wrapper">
                            <div class="swiper-button-prev icon"></div><!-- End .button-prev -->
                            <div class="swiper-button-next icon"></div><!-- End .button-next -->
                        </div><!-- End .swiper-nav-wrapper -->

                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item1.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#office_gadgets</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>125</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>8</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->
                            
                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item2.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#smart_living</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>34</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>13</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item3.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#mobile-accessories</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>14</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>7</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item4.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#mobile-gadgets</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>22</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>5</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item5.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#organization</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>37</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>6</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="ins-feed">
                                    <figure>
                                        <img src="assets/images/instagram/item6.jpg" alt="Item">
                                        <figcaption>
                                            <a href="#" class="btn btn-custom btn-instagram">View Item</a>
                                        </figcaption>
                                    </figure>
                                    <div class="ins-meta">
                                        <a href="#" class="ing-hashtag">#mobile-app</a>
                                        <div class="ins-info">
                                            <a href="#"><i class="icon ins-icon ins-heart"></i><span>41</span></a>
                                            <a href="#"><i class="icon ins-icon ins-comment"></i><span>7</span></a>
                                        </div><!-- End .ins-info -->
                                    </div><!-- End .ins-meta -->
                                </div><!-- End .ins-feed -->
                            </div><!-- End .swiper-slide -->
                        </div><!-- End .swiper-wrapper -->
                    </div><!-- End .swiper-container -->
                </div><!-- End .container-fluid -->

                <div class="mb120 mb90-sm mb70-xs"></div><!-- margin -->

                <div class="container-fluid">
                    <h2 class="carousel-title text-center">PRODUCTS</h2>
                    <div class="swiper-container partners-carousel">
                        <!-- Add Navigation -->
                        <div class="swiper-nav-wrapper">
                            <div class="swiper-button-prev icon"></div><!-- End .button-prev -->
                            <div class="swiper-button-next icon"></div><!-- End .button-next -->
                        </div><!-- End .swiper-nav-wrapper -->

                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="Laptop">
                                        <img src="assets/images/partners/dark/partner1.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="Airpod">
                                        <img src="assets/images/partners/dark/partner2.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="Mobile">
                                        <img src="assets/images/partners/dark/partner3.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="PC">
                                        <img src="assets/images/partners/dark/partner4.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="Gaming Console">
                                        <img src="assets/images/partners/dark/partner5.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="ATM & CC Card">
                                        <img src="assets/images/partners/dark/partner6.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->

                            <div class="swiper-slide">
                                <div class="partner">
                                    <a href="#" title="Bike">
                                        <img src="assets/images/partners/dark/partner7.png" alt="Partner">
                                    </a>
                                </div><!-- End .partner -->
                            </div><!-- End .swiper-slide -->
                            
                           
                        </div><!-- End .swiper-wrapper -->
                    </div><!-- End .swiper-container -->
                </div><!-- End .container-fluid -->

                <div class="mb140 mb100-sm mb80-xs"></div><!-- margin -->

            </div><!-- End .main -->
         
        </div><!-- End #wrapper -->
        <?php include 'footer.php';?>

        <!-- End -->
        <script src="assets/js/plugins.min.js"></script>
        <script src="assets/js/main.js"></script>
        
        <!-- REVOLUTION JS FILES -->
        <script type="text/javascript" src="assets/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery.themepunch.revolution.min.js"></script>

        <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
        (Load Extensions only on Local File Systems !  
        The following part can be removed on Server for On Demand Loading) -->  
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="assets/js/extensions/revolution.extension.video.min.js"></script>

        <script type="text/javascript">
            (function() {
                "use strict";
             
                $(document).ready(function() {
                    var revapi;
                    if ($("#rev_slider").revolution == undefined) {
                        revslider_showDoubleJqueryError("#rev_slider");
                    } else {
                        revapi = $("#rev_slider").show().revolution({
                            sliderType:"standard",
                            jsFileLocation:"assets/js/",
                            sliderLayout:"auto",  
                            dottedOverlay:"none",
                            delay:10000,
                            disableProgressBar: "on",
                            navigation: {
                                keyboardNavigation: "on",
                                keyboard_direction: "horizontal",
                                mouseScrollNavigation: "off",
                                onHoverStop: "off",
                                touch: {
                                    touchenabled: "on",
                                    swipe_threshold: 75,
                                    swipe_min_touches: 1,
                                    swipe_direction: "horizontal",
                                    drag_block_vertical: false
                                },
                                arrows: {
                                    style: "custom",
                                    enable: true,
                                    hide_onmobile: false,
                                    hide_under: 1200,
                                    hide_onleave: false,
                                    tmp: '',
                                    left: {
                                        h_align: "left",
                                        v_align: "center",
                                        h_offset: 58,
                                        v_offset: 0
                                    },
                                    right: {
                                        h_align: "right",
                                        v_align: "center",
                                        h_offset: 58,
                                        v_offset: 0
                                    }
                                },
                                bullets: {
                                    enable: true,
                                    hide_onmobile: false,
                                    hide_under: 767,
                                    style: "custom",
                                    hide_onleave: false,
                                    direction: "horizontal",
                                    h_align: "center",
                                    v_align: "bottom",
                                    h_offset: 0,
                                    v_offset: 40,
                                    space: 15
                                }
                            },
                            viewPort: {
                                enable:true,
                                outof:"pause",
                                visible_area:"80%"
                            },
                            responsiveLevels:[1800,1600,1200,992,767],
                            gridwidth:[1520, 1170,970,750,480],
                            gridheight:[850,680,500,420,280],
                            lazyType:"single",
                            parallax: {
                                type:"mouse",
                                origo:"slidercenter",
                                speed:2000,
                                levels:[2,3,4,5,6,7,12,16,10,50],
                            },
                            shadow:0,
                            spinner:"on",
                            stopLoop:"off",
                            stopAfterLoops:-1,
                            stopAtSlide:-1,
                            shuffle:"off",
                            autoHeight:"off",
                            hideThumbsOnMobile:"off",
                            hideSliderAtLimit:0,
                            hideCaptionAtLimit:0,
                            hideAllCaptionAtLilmit:0,
                            debugMode:false,
                            fallbacks: {
                                simplifyAll:"off",
                                nextSlideOnWindowFocus:"off",
                                disableFocusListener:false,
                            }
                        });

                        
                        $("#rev_slider").bind("revolution.slide.onloaded",function (e) {
                            BackgroundCheck.init({
                                targets: '.tparrows, .tp-bullets, .tp-caption',
                                images: '.tp-bgimg'
                            });
                        });

                        $("#rev_slider").bind("revolution.slide.onafterswap",function (e,data) {
                            BackgroundCheck.refresh();
                        });
                    }
                });

            })();
        </script>
    </body>
</html>